Hello !
This is my font called ""Paper Hand"".
This font is my handwriting, And credit isn't needed, But it would be highly appreciated!

________________________________

I hope you like this font! Cya when i make a new font! ^_^
________________________________

Font made with FontLab 8
________________________________